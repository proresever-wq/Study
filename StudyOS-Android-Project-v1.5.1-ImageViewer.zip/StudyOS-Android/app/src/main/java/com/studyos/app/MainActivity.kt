package com.studyos.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup: String? = null
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    private val aiExecutor = Executors.newSingleThreadExecutor()
    private val aiPrefs by lazy { getSharedPreferences("studyos_ai", MODE_PRIVATE) }

    inner class StudyOSBridge {
        @JavascriptInterface
        fun hasAiKey(): Boolean = !aiPrefs.getString("gemini_key", null).isNullOrBlank()

        @JavascriptInterface
        fun saveAiKey(key: String) {
            if (key.trim().length > 20) aiPrefs.edit().putString("gemini_key", key.trim()).apply()
        }

        @JavascriptInterface
        fun testAiKey(key: String, requestId: String) {
            aiExecutor.execute {
                val result = performGeminiRequest(key.trim(), "Reply with exactly: StudyOS connection OK", 80)
                val ok = result.first
                val message = if (ok) "تم الاتصال بنجاح مع Gemini." else result.second
                val safeId = JSONObject.quote(requestId)
                val safeMessage = JSONObject.quote(message)
                runOnUiThread { webView.evaluateJavascript("window.onAiKeyTest($safeId,$ok,$safeMessage)", null) }
                if (ok) aiPrefs.edit().putString("gemini_key", key.trim()).apply()
            }
        }

        @JavascriptInterface
        fun clearAiKey() { aiPrefs.edit().remove("gemini_key").apply() }

        @JavascriptInterface
        fun askAi(prompt: String, requestId: String) {
            val key = aiPrefs.getString("gemini_key", null)
            if (key.isNullOrBlank()) {
                deliverAi(requestId, "لا يوجد مفتاح Gemini محفوظ. افتح إعدادات المساعد وأضف مفتاحًا صالحًا.", true)
                return
            }
            aiExecutor.execute {
                val result = performGeminiRequest(key, prompt, 1800)
                deliverAi(requestId, result.second, !result.first)
            }
        }

        private fun performGeminiRequest(key: String, prompt: String, maxTokens: Int): Pair<Boolean, String> {
            var connection: HttpURLConnection? = null
            return try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent")
                connection = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", key)
                }
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("temperature", 0.4).put("maxOutputTokens", maxTokens))
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val detail = try {
                        val err = JSONObject(response).optJSONObject("error")
                        val msg = err?.optString("message").orEmpty()
                        val status = err?.optString("status").orEmpty()
                        "Gemini رفض الطلب (HTTP $code${if(status.isNotBlank()) " · $status" else ""}): ${if(msg.isNotBlank()) msg else response.take(500)}"
                    } catch (_: Exception) { "Gemini رفض الطلب (HTTP $code): ${response.take(500)}" }
                    Pair(false, detail)
                } else {
                    val json = JSONObject(response)
                    val candidates = json.optJSONArray("candidates")
                    val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    val answer = parts?.optJSONObject(0)?.optString("text").orEmpty()
                    if (answer.isBlank()) Pair(false, "وصل رد من Gemini لكنه لا يحتوي على نص. قد يكون الرد محجوبًا أو منتهيًا.") else Pair(true, answer)
                }
            } catch (e: Exception) {
                Pair(false, "تعذر الاتصال بـ Gemini: ${e.localizedMessage ?: e.javaClass.simpleName}. تحقق من الإنترنت ثم أعد المحاولة.")
            } finally { connection?.disconnect() }
        }

        private fun deliverAi(id: String, answer: String, error: Boolean) {
            val safeId = JSONObject.quote(id)
            val safeAnswer = JSONObject.quote(answer)
            runOnUiThread { webView.evaluateJavascript("window.onAiReply($safeId,$safeAnswer,$error)", null) }
        }

        @JavascriptInterface
        fun exportBackup(content: String, filename: String) {
            runOnUiThread {
                pendingBackup = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, filename)
                }
                startActivityForResult(intent, REQUEST_CREATE_BACKUP)
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_OPEN_BACKUP)
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(13, 20, 34))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(StudyOSBridge(), "StudyOSBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<android.net.Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/plain"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_PICK_FILES)
                return true
            }
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup = null
            if (requestCode == REQUEST_PICK_FILES) { filePathCallback?.onReceiveValue(null); filePathCallback = null }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_FILES -> {
                val result = if (data.clipData != null) {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                } else arrayOf(uri)
                try { result.forEach { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
                filePathCallback?.onReceiveValue(result)
                filePathCallback = null
            }
            REQUEST_CREATE_BACKUP -> {
                val content = pendingBackup ?: return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                } finally { pendingBackup = null }
            }
            REQUEST_OPEN_BACKUP -> {
                try {
                    val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("Unable to read backup")
                    val safe = org.json.JSONObject.quote(content)
                    webView.evaluateJavascript("window.onNativeBackupLoaded($safe)", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر قراءة ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        aiExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!this::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript("window.handleHardwareBack ? window.handleHardwareBack() : false") { result ->
            if (result != "true") {
                if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
            }
        }
    }

    companion object {
        private const val REQUEST_CREATE_BACKUP = 4101
        private const val REQUEST_OPEN_BACKUP = 4102
        private const val REQUEST_PICK_FILES = 4103
    }
}
