plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "com.studyos.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.studyos.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.3.0"
    }
}
