#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.9+ is required. Use Android Studio or GitHub Actions workflow." >&2
  exit 1
fi
gradle --no-daemon assembleDebug
