#!/usr/bin/env bash
set -euo pipefail
node --check app/src/main/assets/app.js
grep -q 'com.tom-roush:pdfbox-android:2.0.27.0' app/build.gradle.kts
grep -q 'fun extractDocumentText' app/src/main/java/com/studyos/app/MainActivity.kt
grep -q 'indexedFiles' app/src/main/assets/app.js
echo "DERASTAK source checks passed"
grep -q 'FetchContent_Declare(llama_cpp' app/src/main/cpp/CMakeLists.txt
grep -q 'Qwen3-4B-Q4_K_M.gguf' app/src/main/java/com/studyos/app/MainActivity.kt
grep -q 'fun loadLocalModel' app/src/main/java/com/studyos/app/MainActivity.kt
grep -q 'askLocalAi' app/src/main/java/com/studyos/app/MainActivity.kt
grep -q 'externalNativeBuild' app/build.gradle.kts
echo "Local llama.cpp integration checks passed"
