plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
android {
    ndkVersion = "27.2.12479018"
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "com.studyos.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.studyos.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 9
        versionName = "2.2.0-local-ai"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { cppFlags += listOf("-O3", "-fexceptions", "-frtti") } }
    }
}
