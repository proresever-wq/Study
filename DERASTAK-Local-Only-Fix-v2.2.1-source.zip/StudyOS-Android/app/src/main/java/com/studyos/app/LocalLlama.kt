package com.studyos.app

/** JNI facade. Model files live in app-private storage, never inside the APK. */
object LocalLlama {
    init { System.loadLibrary("derastak_llama") }
    @JvmStatic external fun loadModel(modelPath: String, contextSize: Int, threads: Int): String
    @JvmStatic external fun generate(prompt: String, maxTokens: Int, temperature: Float): String
    @JvmStatic external fun unloadModel()
    @JvmStatic external fun isLoaded(): Boolean
}
