package com.studyos.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.database.Cursor
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import android.widget.Toast
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup: String? = null
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    private val aiExecutor = Executors.newSingleThreadExecutor()
    private val aiPrefs by lazy { getSharedPreferences("studyos_ai", MODE_PRIVATE) }

    inner class StudyOSBridge {
        @JavascriptInterface
        fun extractDocumentText(base64: String, filename: String, requestId: String) {
            aiExecutor.execute {
                val result = try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val lower = filename.lowercase()
                    val text = when {
                        lower.endsWith(".pdf") -> {
                            PDFBoxResourceLoader.init(applicationContext)
                            PDDocument.load(bytes).use { doc ->
                                val stripper = PDFTextStripper()
                                val pages = StringBuilder()
                                for (page in 1..doc.numberOfPages) {
                                    stripper.startPage = page
                                    stripper.endPage = page
                                    pages.append("\n[صفحة ").append(page).append("]\n")
                                    pages.append(stripper.getText(doc)).append('\n')
                                }
                                pages.toString()
                            }
                        }
                        lower.endsWith(".docx") || lower.endsWith(".pptx") -> extractOfficeXml(bytes, lower.endsWith(".docx"))
                        else -> ""
                    }
                    text.take(500_000)
                } catch (e: Exception) { "" }
                val safeId = JSONObject.quote(requestId)
                val safeText = JSONObject.quote(result)
                runOnUiThread { webView.evaluateJavascript("window.onDocumentText($safeId,$safeText)", null) }
            }
        }

        private fun extractOfficeXml(bytes: ByteArray, isDocx: Boolean): String {
            val out = StringBuilder()
            ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name
                    val wanted = if (isDocx) name == "word/document.xml" else name.matches(Regex("ppt/slides/slide[0-9]+\\.xml"))
                    if (wanted) {
                        val xml = zip.readBytes().toString(Charsets.UTF_8)
                        Regex("<(?:w|a):t(?:\\s[^>]*)?>(.*?)</(?:w|a):t>", setOf(RegexOption.DOT_MATCHES_ALL)).findAll(xml).forEach {
                            out.append(it.groupValues[1].replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">"))
                            out.append(' ')
                        }
                    }
                    zip.closeEntry()
                }
            }
            return out.toString()
        }

        @JavascriptInterface
        fun hasLocalModelFile(): Boolean = modelFile().let { it.exists() && it.length() > 1_000_000_000L }

        @JavascriptInterface
        fun isLocalModelLoaded(): Boolean = try { LocalLlama.isLoaded() } catch (_: Throwable) { false }

        @JavascriptInterface
        fun localModelStatus(): String {
            val file = modelFile()
            if (isLocalModelLoaded()) return "loaded"
            if (file.exists() && file.length() > 1_000_000_000L) return "downloaded"
            val id = aiPrefs.getLong("model_download_id", -1L)
            if (id > 0) {
                val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val cursor = manager.query(DownloadManager.Query().setFilterById(id))
                cursor?.use {
                    if (it.moveToFirst()) {
                        when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                            DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PENDING -> return "downloading"
                            DownloadManager.STATUS_FAILED -> return "failed"
                            DownloadManager.STATUS_SUCCESSFUL -> return if (file.exists() && file.length() > 1_000_000_000L) "downloaded" else "failed"
                        }
                    }
                }
            }
            return "missing"
        }

        @JavascriptInterface
        fun downloadLocalModel() {
            aiExecutor.execute {
                try {
                    val status = localModelStatus()
                    if (status == "downloading" || status == "downloaded" || status == "loaded") {
                        notifyLocalModel("النموذج موجود بالفعل أو يجري تنزيله.", status)
                        return@execute
                    }
                    val file = modelFile()
                    if (file.exists()) file.delete()
                    val request = DownloadManager.Request(Uri.parse(LOCAL_MODEL_URL))
                        .setTitle("تنزيل نموذج دراستك Qwen3-4B")
                        .setDescription("حوالي 2.5GB — يفضّل استخدام Wi-Fi ومساحة فارغة لا تقل عن 5GB")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setAllowedOverMetered(false)
                        .setAllowedOverRoaming(false)
                        .setDestinationInExternalFilesDir(this@MainActivity, null, "models/$LOCAL_MODEL_FILE")
                    val id = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                    aiPrefs.edit().putLong("model_download_id", id).apply()
                    notifyLocalModel("بدأ تنزيل النموذج. اترك التنزيل يكتمل من إشعارات أندرويد.", "downloading")
                } catch (e: Exception) {
                    notifyLocalModel("تعذر بدء تنزيل النموذج: ${e.localizedMessage}", "failed")
                }
            }
        }

        @JavascriptInterface
        fun loadLocalModel() {
            aiExecutor.execute {
                val file = modelFile()
                if (!file.exists() || file.length() < 1_000_000_000L) {
                    notifyLocalModel("ملف النموذج غير مكتمل. نزّله أولًا.", "missing")
                    return@execute
                }
                try {
                    val digest = java.security.MessageDigest.getInstance("SHA-256")
                    file.inputStream().buffered().use { input ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) { val read = input.read(buffer); if (read < 0) break; digest.update(buffer, 0, read) }
                    }
                    val sha = digest.digest().joinToString("") { "%02x".format(it) }
                    if (sha != LOCAL_MODEL_SHA256) {
                        file.delete()
                        notifyLocalModel("فشل التحقق من سلامة النموذج؛ حُذف الملف التالف. أعد التنزيل.", "failed")
                        return@execute
                    }
                    val result = LocalLlama.loadModel(file.absolutePath, 2048, Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
                    notifyLocalModel(result, if (LocalLlama.isLoaded()) "loaded" else "failed")
                } catch (e: Throwable) {
                    notifyLocalModel("تعذر تشغيل محرك الذكاء الاصطناعي: ${e.localizedMessage ?: e.javaClass.simpleName}", "failed")
                }
            }
        }

        @JavascriptInterface
        fun askLocalAi(prompt: String, requestId: String) {
            if (!isLocalModelLoaded()) {
                deliverAi(requestId, "النموذج المحلي غير محمّل. نزّل Qwen وشغّله أولًا من الإعدادات.", true)
                return
            }
            aiExecutor.execute {
                try {
                    val answer = LocalLlama.generate(prompt, 512, 0.45f)
                    if (answer.isBlank()) deliverAi(requestId, "النموذج لم يُرجع إجابة. جرّب سؤالًا أقصر.", true)
                    else deliverAi(requestId, answer, false)
                } catch (e: Throwable) {
                    deliverAi(requestId, "تعذر تشغيل النموذج المحلي: ${e.localizedMessage ?: e.javaClass.simpleName}", true)
                }
            }
        }

        private fun notifyLocalModel(message: String, status: String) {
            val safeMessage = JSONObject.quote(message)
            val safeStatus = JSONObject.quote(status)
            runOnUiThread { webView.evaluateJavascript("window.onLocalModelStatus?.($safeMessage,$safeStatus)", null) }
        }

        /**
         * Calls the stable primary model, retries transient failures with backoff,
         * then tries the lighter fallback model once. Invalid keys / malformed
         * requests are returned immediately and are never retried.
         */
        private fun deliverAi(id: String, answer: String, error: Boolean) {
            val safeId = JSONObject.quote(id)
            val safeAnswer = JSONObject.quote(answer)
            runOnUiThread { webView.evaluateJavascript("window.onAiReply($safeId,$safeAnswer,$error)", null) }
        }

        @JavascriptInterface
        fun exportBackup(content: String, filename: String) {
            runOnUiThread {
                pendingBackup = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, filename)
                }
                startActivityForResult(intent, REQUEST_CREATE_BACKUP)
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_OPEN_BACKUP)
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(13, 20, 34))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(StudyOSBridge(), "StudyOSBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<android.net.Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/plain"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_PICK_FILES)
                return true
            }
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup = null
            if (requestCode == REQUEST_PICK_FILES) { filePathCallback?.onReceiveValue(null); filePathCallback = null }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_FILES -> {
                val result = if (data.clipData != null) {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                } else arrayOf(uri)
                try { result.forEach { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
                filePathCallback?.onReceiveValue(result)
                filePathCallback = null
            }
            REQUEST_CREATE_BACKUP -> {
                val content = pendingBackup ?: return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                } finally { pendingBackup = null }
            }
            REQUEST_OPEN_BACKUP -> {
                try {
                    val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("Unable to read backup")
                    val safe = org.json.JSONObject.quote(content)
                    webView.evaluateJavascript("window.onNativeBackupLoaded($safe)", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر قراءة ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        aiExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!this::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript("window.handleHardwareBack ? window.handleHardwareBack() : false") { result ->
            if (result != "true") {
                if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
            }
        }
    }

    companion object {
        private const val LOCAL_MODEL_FILE = "Qwen3-4B-Q4_K_M.gguf"
        private const val LOCAL_MODEL_URL = "https://huggingface.co/ggml-org/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf"
        private const val LOCAL_MODEL_SHA256 = "ab27b9bfa375a178d6cba48f3ad892b94b7739659dcc7aae8058ce0ffed6b328"
        private const val REQUEST_CREATE_BACKUP = 4101
        private const val REQUEST_OPEN_BACKUP = 4102
        private const val REQUEST_PICK_FILES = 4103
    }
}
