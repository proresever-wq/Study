#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"
static llama_model * model = nullptr;
static llama_context * context = nullptr;
static std::mutex engineMutex;
static std::string fromJava(JNIEnv *e, jstring s) {
    if (!s) return {};
    const char *p = e->GetStringUTFChars(s, nullptr);
    std::string v = p ? p : "";
    if (p) e->ReleaseStringUTFChars(s, p);
    return v;
}
static jstring toJava(JNIEnv *e, const std::string &s) { return e->NewStringUTF(s.c_str()); }
static void closeEngine() {
    if (context) { llama_free(context); context = nullptr; }
    if (model) { llama_model_free(model); model = nullptr; }
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_studyos_app_LocalLlama_loadModel(JNIEnv *e, jclass, jstring path, jint ctxSize, jint threads) {
    std::lock_guard<std::mutex> lock(engineMutex);
    closeEngine();
    std::string p = fromJava(e, path);
    if (p.empty()) return toJava(e, "مسار النموذج فارغ.");
    llama_backend_init();
    auto mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // CPU first; Mali GPU offload is not assumed.
    model = llama_model_load_from_file(p.c_str(), mp);
    if (!model) return toJava(e, "تعذر فتح ملف GGUF. تأكد من اكتمال التنزيل.");
    auto cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) std::clamp((int)ctxSize, 512, 4096);
    cp.n_batch = 512;
    cp.n_threads = std::clamp((int)threads, 2, 6);
    cp.n_threads_batch = cp.n_threads;
    context = llama_init_from_model(model, cp);
    if (!context) { closeEngine(); return toJava(e, "تعذر إنشاء سياق النموذج؛ الذاكرة المتاحة غير كافية."); }
    return toJava(e, "تم تحميل النموذج المحلي بنجاح.");
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_studyos_app_LocalLlama_generate(JNIEnv *e, jclass, jstring input, jint maxTokens, jfloat temp) {
    std::lock_guard<std::mutex> lock(engineMutex);
    if (!model || !context) return toJava(e, "النموذج المحلي غير محمّل.");
    const std::string userText = fromJava(e, input);
    // Qwen3 instruct chat template (system + user + assistant prefix).
    std::string prompt = "<|im_start|>system\nأنت مساعد دراسي دقيق. أجب بلغة المستخدم، واشرح خطوة بخطوة عند الطلب. لا تخترع معلومات غير موجودة في السياق.\n<|im_end|>\n<|im_start|>user\n" + userText + "<|im_end|>\n<|im_start|>assistant\n";
    const llama_vocab *vocab = llama_model_get_vocab(model);
    int32_t n = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), nullptr, 0, true, true);
    if (n >= 0) return toJava(e, "تعذر تحويل السؤال إلى tokens.");
    std::vector<llama_token> toks((size_t)-n);
    n = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), toks.data(), (int32_t)toks.size(), true, true);
    if (n < 0) return toJava(e, "فشل تجهيز السؤال.");
    toks.resize((size_t)n);
    if (toks.size() + 8 >= llama_n_ctx(context)) return toJava(e, "السياق أطول من سعة النموذج؛ اختصر السؤال أو الملفات المرفقة.");
    llama_memory_clear(llama_get_memory(context), true);
    llama_batch batch = llama_batch_get_one(toks.data(), (int32_t)toks.size());
    if (llama_decode(context, batch) != 0) return toJava(e, "فشل تحليل السؤال داخل النموذج.");
    auto sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(std::clamp((float)temp, 0.1f, 1.2f)));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    std::string answer;
    int limit = std::clamp((int)maxTokens, 16, 768);
    for (int i = 0; i < limit; ++i) {
        llama_token token = llama_sampler_sample(sampler, context, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        char piece[512];
        int32_t len = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, true);
        if (len > 0) answer.append(piece, (size_t)len);
        llama_sampler_accept(sampler, token);
        batch = llama_batch_get_one(&token, 1);
        if (llama_decode(context, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    return toJava(e, answer.empty() ? "لم ينتج النموذج إجابة." : answer);
}
extern "C" JNIEXPORT void JNICALL
Java_com_studyos_app_LocalLlama_unloadModel(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(engineMutex); closeEngine();
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_studyos_app_LocalLlama_isLoaded(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(engineMutex); return model && context ? JNI_TRUE : JNI_FALSE;
}
