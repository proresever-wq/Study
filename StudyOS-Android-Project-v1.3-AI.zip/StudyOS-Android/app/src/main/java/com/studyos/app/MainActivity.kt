package com.studyos.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup: String? = null
    private val aiExecutor = Executors.newSingleThreadExecutor()
    private val aiPrefs by lazy { getSharedPreferences("studyos_ai", MODE_PRIVATE) }

    inner class StudyOSBridge {
        @JavascriptInterface
        fun hasAiKey(): Boolean = !aiPrefs.getString("gemini_key", null).isNullOrBlank()

        @JavascriptInterface
        fun saveAiKey(key: String) {
            if (key.startsWith("AIza") && key.length > 20) aiPrefs.edit().putString("gemini_key", key).apply()
        }

        @JavascriptInterface
        fun clearAiKey() { aiPrefs.edit().remove("gemini_key").apply() }

        @JavascriptInterface
        fun askAi(prompt: String, requestId: String) {
            val key = aiPrefs.getString("gemini_key", null)
            if (key.isNullOrBlank()) {
                deliverAi(requestId, "", true)
                return
            }
            aiExecutor.execute {
                try {
                    val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent")
                    val connection = (endpoint.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 15000
                        readTimeout = 30000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("x-goog-api-key", key)
                    }
                    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                        .put("generationConfig", JSONObject().put("temperature", 0.4).put("maxOutputTokens", 1800))
                    OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                    val code = connection.responseCode
                    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                    val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    connection.disconnect()
                    if (code !in 200..299) throw IllegalStateException("Gemini HTTP $code")
                    val json = JSONObject(response)
                    val answer = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    deliverAi(requestId, answer, false)
                } catch (e: Exception) {
                    deliverAi(requestId, "", true)
                }
            }
        }

        private fun deliverAi(id: String, answer: String, error: Boolean) {
            val safeId = JSONObject.quote(id)
            val safeAnswer = JSONObject.quote(answer)
            runOnUiThread { webView.evaluateJavascript("window.onAiReply($safeId,$safeAnswer,$error)", null) }
        }

        @JavascriptInterface
        fun exportBackup(content: String, filename: String) {
            runOnUiThread {
                pendingBackup = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, filename)
                }
                startActivityForResult(intent, REQUEST_CREATE_BACKUP)
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQUEST_OPEN_BACKUP)
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(13, 20, 34))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(StudyOSBridge(), "StudyOSBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup = null
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_CREATE_BACKUP -> {
                val content = pendingBackup ?: return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                } finally { pendingBackup = null }
            }
            REQUEST_OPEN_BACKUP -> {
                try {
                    val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("Unable to read backup")
                    val safe = org.json.JSONObject.quote(content)
                    webView.evaluateJavascript("window.onNativeBackupLoaded($safe)", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر قراءة ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        aiExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    companion object {
        private const val REQUEST_CREATE_BACKUP = 4101
        private const val REQUEST_OPEN_BACKUP = 4102
    }
}
