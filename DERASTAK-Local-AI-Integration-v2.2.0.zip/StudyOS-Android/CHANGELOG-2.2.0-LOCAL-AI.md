# DERASTAK 2.2.0 — Local AI integration

- Added Android NDK/CMake native build for llama.cpp, ARM64 CPU backend.
- Added JNI bridge for model loading, tokenization, decoding and generation.
- Added in-app Qwen3-4B Q4_K_M download to app-specific storage (model is not embedded in APK).
- Added SHA-256 integrity verification before loading the downloaded model.
- Added native model controls in Assistant settings; local inference is preferred when available.
- Updated GitHub Actions to install NDK 27.2.12479018 and CMake 3.22.1.

## Validation boundary
JavaScript syntax and source integration checks pass. Android APK/native compilation has not been run in this environment because Android SDK/NDK and Gradle are unavailable. The GitHub Actions build is the first full compiler validation. Semantic RAG/embeddings, OCR/vision, and complete exam/task feature scope are not claimed as finished by this update.
